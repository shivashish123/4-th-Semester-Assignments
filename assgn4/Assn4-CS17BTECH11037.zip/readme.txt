For compiling the Reader-Writer program :
g++ rw-CS17BTECH11037.cpp -pthread -std=c++11

For compiling the Fair Reader-Writer program :
g++ frw-CS17BTECH11037.cpp -pthread -std=c++11 

For running the program:
./a.out

Input will be taken from 'inp-params.txt' and output will be generated in "<program>-Log.txt" and 
"Average_time-<program>.txt" where program may be "RW" or "FairRW".