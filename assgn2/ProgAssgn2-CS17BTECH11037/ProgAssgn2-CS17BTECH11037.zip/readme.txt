For compiling the TAS program :
g++ SrcAssgn2-TAS-CS17BTECH11037.cpp -pthread -std=c++11

For compiling the CAS program :
g++ SrcAssgn2-CAS-CS17BTECH11037.cpp -pthread -std=c++11 

For compiling the CAS program :
g++ SrcAssgn2-CAS-BOUNDED-CS17BTECH11037.cpp -pthread -std=c++11 

For running the program:
./a.out

Input will be taken from 'inp-params.txt' and output will be generated in "<program>-Log.txt" and "Averagetime-program.txt" where program may be "TAS", "CAS" and "CAS_bounded".